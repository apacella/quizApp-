package net.androidbootcamp.compuquiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import net.androidbootcamp.compuquiz.QuizContract.*;

import java.util.ArrayList;
import java.util.List;


public class QuizDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "CompUQuiz.db";
    private static final int DATABASE_VERSION = 3;

    private static QuizDBHelper instance;

    private SQLiteDatabase db; //holds DB refernce to actual DB

    private QuizDBHelper( Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized QuizDBHelper  getInstance(Context context){//prevents a memeory leak if multiple tables end up running
        if (instance == null){
            instance = new QuizDBHelper(context.getApplicationContext());
        }
        return instance; //returns existing table if there is already a table running
    }

    @Override
    public void onCreate(SQLiteDatabase db) { //creates initial DB passes refernece to the DB to it
        this.db = db;//used to add values to db

        final String SQL_CREATE_CATEGORIES_TABLE = "CREATE TABLE " +
                CategoriesTable.TABLE_NAME + "( " +
                CategoriesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CategoriesTable.COULMN_NAME + " TEXT " +
                ")";


        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionsTable.COLUMN_DIFFICULTY + " TEXT, " +
                QuestionsTable.COLUMN_CATEGORY_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuestionsTable.COLUMN_CATEGORY_ID + ") REFERENCES " +
                CategoriesTable.TABLE_NAME + "(" + CategoriesTable._ID +")" + "ON DELETE CASCADE" +
                ")"; //the above creates the table for the SQLite DB

        db.execSQL(SQL_CREATE_CATEGORIES_TABLE);
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);//only called once
        fillCategoriesTable();
        fillQuestionsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { //tells app to update
        db.execSQL("DROP TABLE IF EXISTS " + CategoriesTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);//will need to change version number
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    private void fillCategoriesTable(){
        Category c1 = new Category("Programming");
        insertCategory(c1);
        Category c2 = new Category("Hardware");
        insertCategory(c2);
        //Category c3 = new Category("General Computer Knowledge");
        //insertCategory(c3);
    }

    //call this for addition of single category
    public void addCategory(Category category){//method allowing for user addition of categories
        db = getWritableDatabase(); //no recursion
        insertCategory(category);
    }

    public void addCategories(List<Category> categories){ //call for multiple addition of categories at once
        db = getWritableDatabase();
        for (Category category : categories){
            insertCategory(category);
        }
    }

    private void insertCategory(Category category){//insets categories into the SQLite DB
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COULMN_NAME, category.getName());
        db.insert(CategoriesTable.TABLE_NAME, null, cv);
    }

    private void fillQuestionsTable() {
        //programming easy
        Question question1 = new Question("What is a variable?",
                "Good question ", "a value that can change", "An array of elements",2, Question.DIFFICULTY_EASY, Category.PROGRAMMING);
        insertQuestion(question1);
        Question question2 = new Question("Which is a variable type that allows decimals?",
                "int", "string", "double", 3, Question.DIFFICULTY_EASY, Category.PROGRAMMING);
        insertQuestion(question2);
        Question question3 = new Question("what variable type is \"Hello World\"?",
                "int", "string", "double", 2, Question.DIFFICULTY_EASY, Category.PROGRAMMING);
        insertQuestion(question3);
        Question question4 = new Question("What is the syntax for a method? ",
                "public void methodName(){}", "methodName", "String methodName", 1, Question.DIFFICULTY_EASY, Category.PROGRAMMING);
        insertQuestion(question4);
        Question question5 = new Question("Which is a variable type does not allow decimals?",
                "Float", "Double", "String", 3, Question.DIFFICULTY_EASY, Category.PROGRAMMING);
        insertQuestion(question5);

        //programming Medium
        Question question6 = new Question("Which condition is best used when you know how many iterations you need?",
                "For Loop", "While loop", "If else", 1, Question.DIFFICULTY_MEDIUM, Category.PROGRAMMING);
        insertQuestion(question6);
        Question question7 = new Question("Which condition tests the statement at least once?",
                "For loop", "Do While loop", "While loop", 2, Question.DIFFICULTY_MEDIUM, Category.PROGRAMMING);
        insertQuestion(question7);
        Question question8 = new Question("Which array is expandable automatically? ",
                "Array[]", "Arrays don't automatically expand", "ArrayList<>", 3, Question.DIFFICULTY_MEDIUM, Category.PROGRAMMING);
        insertQuestion(question8);
        Question question9 = new Question("What is the syntax for an Array creation?",
                "variableType[] name ", "[] name ", "variableType = []", 1, Question.DIFFICULTY_MEDIUM, Category.PROGRAMMING);
        insertQuestion(question9);
        Question question10 = new Question("Which condition has to satisfy the rule before testing?",
                "For loop", "Do While loop", "While loop", 3, Question.DIFFICULTY_MEDIUM, Category.PROGRAMMING);
        insertQuestion(question10);

        //programming Hard
        Question question11 = new Question("A ternary operator is ",
                "A simplified if else statement", "A form of Do While loop", "A changeable value based on input", 1,
                Question.DIFFICULTY_HARD, Category.PROGRAMMING);
        insertQuestion(question11);
        Question question12 = new Question("What is the syntax for a Lambda Expression",
                "Statement ? condition : condition", " => ", "For(counter : condition : increment", 2, Question.DIFFICULTY_HARD, Category.PROGRAMMING);
        insertQuestion(question12);
        Question question13 = new Question("Inheritance is ",
                "Getting an object from someone", "To inherit the properties of a class to fill a need.", "Create a class to pass to another",
                2, Question.DIFFICULTY_HARD, Category.PROGRAMMING);
        insertQuestion(question13);
        Question question14 = new Question("In Java composition is  ",
                "Based on an Is a relationship", "the breakdown of code", "Based on a Has a relationship", 3,
                Question.DIFFICULTY_HARD, Category.PROGRAMMING);
        insertQuestion(question14);
        Question question15 = new Question("Inheritance is based off of a(n) ",
                "Is a relationship", "Based on a Has a relationship", "Negative relationship", 1,
                Question.DIFFICULTY_HARD, Category.PROGRAMMING);
        insertQuestion(question15);

        //Hardware easy
        Question question16 = new Question("Which of this is an input?",
                "Screen", "Power cable", "Keyboard",3, Question.DIFFICULTY_EASY, Category.HARDWARE);
        insertQuestion(question16);
        Question question17 = new Question("Which of these produces an output",
                "Screen", "Mouse", "Keyboard", 1, Question.DIFFICULTY_EASY, Category.HARDWARE);
        insertQuestion(question17);
        Question question18 = new Question("What is the object used for typing?",
                "Keyboard", "Power cable", "Screen",1, Question.DIFFICULTY_EASY, Category.HARDWARE);
        insertQuestion(question18);
        Question question19 = new Question("Which computer below is easily portable?",
                "Servers", "Laptop", "Desktop",2, Question.DIFFICULTY_EASY, Category.HARDWARE);
        insertQuestion(question19);
        Question question20 = new Question("What powers on the computer?",
                "Left mouse button", "Power button", "Keyboard",2, Question.DIFFICULTY_EASY, Category.HARDWARE);
        insertQuestion(question20);

        //Hardware medium
        Question question21 = new Question("What does RAM stand for?",
                "Read Access Memory", "Random Access Memory", "Really Awesome Memory", 2, Question.DIFFICULTY_MEDIUM, Category.HARDWARE);
        insertQuestion(question21);
        Question question22 = new Question("What is a motherboard?",
                "Involved in the RAM of the system", "Circuit board containing the principle components of a computer", "The adult of the baby board",
                2, Question.DIFFICULTY_MEDIUM, Category.HARDWARE);
        insertQuestion(question22);
        Question question23 = new Question("How much RAM cards can a computer hold?",
                "Depends on available space", "No more than 2 cards ", "Only one", 1, Question.DIFFICULTY_MEDIUM, Category.HARDWARE);
        insertQuestion(question23);
        Question question24 = new Question("What are the two types of hard drives?",
                "Broken state hard drive", "Soft disk hard drive and its the only one", "Hard disk and solid state",
                3, Question.DIFFICULTY_MEDIUM, Category.HARDWARE);
        insertQuestion(question24);
        Question question25 = new Question("What chip is responsible for handling all of the information in the programs?",
                "The hard drive", "The Graphics card", "The processor", 3, Question.DIFFICULTY_MEDIUM, Category.HARDWARE);
        insertQuestion(question25);

        //Hardware hard
        Question question26 = new Question("If you don't have a wireless internet adapter card, what can you do to connect to the internet?",
                "Connect an HDMI cable", "shut the system down and walk away", "Use an ethernet cable", 3,
                Question.DIFFICULTY_HARD, Category.HARDWARE);
        insertQuestion(question26);
        Question question27 = new Question("What is another name for an RJ45 plug?",
                "Ethernet cable", "HDMI cable", "USB", 1, Question.DIFFICULTY_HARD, Category.HARDWARE);
        insertQuestion(question27);
        Question question28 = new Question("Which of these is the fastest?",
                "Solid State hard drive", "Hard disk drive", "They are equal", 1,
                Question.DIFFICULTY_HARD, Category.HARDWARE);
        insertQuestion(question28);
        Question question29 = new Question("What is the purpose of a DB25 plug?",
                "Its the power cord for the computer", "It allows for the asynchronous transmission of data", "Screen output", 2,
                Question.DIFFICULTY_HARD, Category.HARDWARE);
        insertQuestion(question29);
        Question question30 = new Question("What is the DB9 connection most commonly used for?",
                "This doesn't exist", "Connection of peripherals", "Transfer of data", 2,
                Question.DIFFICULTY_HARD, Category.HARDWARE);
        insertQuestion(question30);

        //general computer knowledge 2 easy 2 medium 2 hard

    }

    public void addQuestion(Question question){
        db = getWritableDatabase();
        insertQuestion(question);
    }
    public void addQuestions(List<Question> questions){

        db = getWritableDatabase();
        for (Question question : questions){
            insertQuestion(question);
        }
    }

    private void insertQuestion(Question question){
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionsTable.COLUMN_DIFFICULTY, question.getDifficulty());
        cv.put(QuestionsTable.COLUMN_CATEGORY_ID, question.getCategoryID());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Category> getALLCategories(){
        List<Category> categoryList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + CategoriesTable.TABLE_NAME, null);

        if(c.moveToFirst()){
            do{
                Category category = new Category();
                category.setId(c.getInt(c.getColumnIndex(CategoriesTable._ID)));
                category.setName(c.getString(c.getColumnIndex(CategoriesTable.COULMN_NAME)));
                categoryList.add(category);
            }while (c.moveToNext());
        }
        c.close();
        return categoryList;
    }

    public ArrayList<Question> getAllQuestions(){
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase(); //calls db oncreate method and creates db
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);

        if(c.moveToFirst()) {
            do{
                Question question = new Question();//pulls in the question index saves as question string
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setDifficulty(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY_ID)));
                questionList.add(question); //this section passes the questions and answers if they exist
            }while(c.moveToNext());
        }//end if

        c.close();//close cursor
        return questionList;
    }//end method

    public ArrayList<Question> getQuestions(int categoryID, String difficulty) {
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();

        String selection = QuestionsTable.COLUMN_CATEGORY_ID + " = ? " +
                " AND " + QuestionsTable.COLUMN_DIFFICULTY + " = ? ";
        String[] selectionsArgs = new String[]{String.valueOf(categoryID), difficulty};
        Cursor c = db.query(
                QuestionsTable.TABLE_NAME,
                null,
                selection,
                selectionsArgs,
                null, //dont want to order or group the query
                null,
                null
        );

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setDifficulty(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY_ID)));
                questionList.add(question); //this section passes the questions and answers if they exist
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }
}

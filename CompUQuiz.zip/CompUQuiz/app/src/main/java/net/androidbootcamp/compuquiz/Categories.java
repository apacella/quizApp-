package net.androidbootcamp.compuquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Categories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);
        Button startBtnQuiz = findViewById(R.id.categoryBtn1); //variable for later use

        startBtnQuiz.setOnClickListener(new View.OnClickListener() { //user selects start, will eventually go to
            //category screen
            @Override
            public void onClick(View view) {
                startQuiz();
            }
        });
    }
    private void startQuiz(){ //change this to categories section, use this method to go to the quiz
        Intent intent = new Intent(Categories.this, QuizActivity.class);
        startActivity(intent);//opens second activity
    }
}

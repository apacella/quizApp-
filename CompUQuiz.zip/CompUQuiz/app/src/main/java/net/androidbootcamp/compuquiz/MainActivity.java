package net.androidbootcamp.compuquiz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_QUIZ_CODE = 1;
    public static final String EXTRA_CATEGORYID = "extraCategoryID";
    public static final String EXTRA_CATEGORY_NAME = "extraCategoryName";
    public static final String EXTRA_DIFFICULTY = "extraDifficulty";

    public static final String SHARED_PREF = "sharedPref";
    public static final String CURRENT_HIGH_SCORE = "currentHighScore";//saved score constant in shared prefs

    private TextView highScoreTxtView;
    private Spinner spinnerCategory;
    private Spinner spinnerDifficulty;
    private int highScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        highScoreTxtView = findViewById(R.id.text_view_highscore);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty);
        loadHighScore();
        loadCategories();
        loadDifficultyLevels();



        Button startBtnQuiz = findViewById(R.id.startBtn); //variable for later use
        startBtnQuiz.setOnClickListener(new View.OnClickListener() { //user selects start, will eventually go to
            //categorty screen
            @Override
            public void onClick(View v) {
                startQuiz();
            }
        });

        Button addQuestionBtn = findViewById(R.id.addQuestionBtn); //variable for later use
        addQuestionBtn.setOnClickListener(new View.OnClickListener() { //user selects start, will eventually go to
            //categorty screen
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddQuestions.class));

            }
        });
       /* Button addQuestionsBtn = findViewById(R.id.addQuestionBtn);
        addQuestionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addQuestionScreen();
            }
        });*/

        //below is the call to use to have the user add a question.
        //has not been tested may not work like this.
       // QuizDBHelper.getInstance(this).addQuestion(findViewById(R.id.));
    }//end oncreate

   /* private void addQuestionScreen(){
        Intent addIntent = new Intent(MainActivity.this, AddQuestions.class);
        Category selectedCategory = (Category) spinnerCategory.getSelectedItem();
        int categoryID = selectedCategory.getId();
        String categoryName = selectedCategory.getName();

        String difficulty = spinnerDifficulty.getSelectedItem().toString();//this gets the selection and saves it here
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);

        intent.putExtra(EXTRA_CATEGORYID,categoryID);
        intent.putExtra(EXTRA_CATEGORY_NAME, categoryName);
        intent.putExtra(EXTRA_DIFFICULTY, difficulty);
        startActivityForResult(intent, REQUEST_QUIZ_CODE);//opens second activity
    }*/

    private void startQuiz(){ //change this to categories section, use this method to go to the quiz
        Category selectedCategory = (Category) spinnerCategory.getSelectedItem();
        int categoryID = selectedCategory.getId();
        String categoryName = selectedCategory.getName();

        String difficulty = spinnerDifficulty.getSelectedItem().toString();//this gets the selection and saves it here
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);

        intent.putExtra(EXTRA_CATEGORYID,categoryID);
        intent.putExtra(EXTRA_CATEGORY_NAME, categoryName);
        intent.putExtra(EXTRA_DIFFICULTY, difficulty);
        startActivityForResult(intent, REQUEST_QUIZ_CODE);//opens second activity

    }//end start quiz

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {//data is where the score value is saved
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_QUIZ_CODE){//compars requestCode to named constant
            if(resultCode == RESULT_OK){
                int score = data.getIntExtra(QuizActivity.EXTRA_SCORE, 0);
                if(score > highScore){
                    updateHighScore(score);
                }//end if
            }//end if
        }//end if
    }//end Result

    private void loadCategories(){
        QuizDBHelper dbHelper = QuizDBHelper.getInstance(this);
        List<Category> categories = dbHelper.getALLCategories();

        ArrayAdapter<Category> adapterCategories = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapterCategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapterCategories);
    }
    private void loadDifficultyLevels(){
        String[] difficultyLevels = Question.getAllDifficultyLevels(); //calls method on the class itself

        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, difficultyLevels);
        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinnerDifficulty.setAdapter(adapterDifficulty);//fills spinner with the difficulty levels from getAllDifficultyLevels method
    }

    private void loadHighScore(){
        SharedPreferences prefs = getSharedPreferences(SHARED_PREF, MODE_PRIVATE);
        //no editor.apply because shared preferences doesnt need to be saved
        highScore = prefs.getInt(CURRENT_HIGH_SCORE,4);//gets int from shared
        highScoreTxtView.setText("High Score: " + highScore);//reset text to new high score
    }

    private void updateHighScore(int newHighScore){//take in the new high score
        highScore = newHighScore;//assign to high score variable
        highScoreTxtView.setText("High Score: " + highScore);//reset text to new high score

        SharedPreferences prefs = getSharedPreferences(SHARED_PREF, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();//used to save variables (high score) into this variable
        editor.putInt(CURRENT_HIGH_SCORE, highScore);//passes key to highscore
        editor.apply();//saves above
    }//end method

    //auto generated below this comment
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }//end options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }//end options
}//end main

package net.androidbootcamp.compuquiz;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

public class QuizActivity extends AppCompatActivity {

    public static final String EXTRA_SCORE = "extraScore";
    private static final long TIMER_IN_MILLIS = 30000; //30 seconds per questions

    private static final String KEY_SCORE = "keyScore";
    private static final String KEY_QUESTION_COUNT = "keyQuestionCount";
    private static final String KEY_MILLIS_LEFT = "keyMillisLeft";
    private static final String KEY_ANSWERED = "keyAnswered";
    private static final String KEY_QUESTION_LIST = "keyQuestionList";//takes in array list


    private TextView textViewQuesion;
    private TextView textViewScore;
    private TextView textViewQuestionCount;
    private TextView textViewCategory;
    private TextView textViewDifficulty;
    private TextView textViewCountdown;
    private RadioGroup rbGroup;
    private RadioButton radio1;
    private RadioButton radio2;
    private RadioButton radio3;
    private Button confirmSubmt;

    private ColorStateList textColorDefaultRb; //saves text color for selections default
    private ColorStateList TextColorDefaultCd;//save text color of timer

    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;


    private ArrayList<Question> questionList;
    private int questionCounter;//counts questions
    private int questionCountTotal;//shows the amount of questions left
    private Question currentQuestion;

    private int score;
    private boolean answered;//decides to lock answer or show next questions

    private long backBtnPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        textViewQuesion = findViewById(R.id.txtViewQuestion);
        textViewScore = findViewById(R.id.scoreLblQuestScreen);
        textViewQuestionCount = findViewById(R.id.questionCountTxtView);
        textViewCategory = findViewById(R.id.txtViewCategory);
        textViewDifficulty = findViewById(R.id.txtViewDifficulty);
        textViewCountdown = findViewById(R.id.countdownTxtView);
        rbGroup = findViewById(R.id.radio_group);
        radio1 = findViewById(R.id.optionOne);
        radio2 = findViewById(R.id.optionTwo);
        radio3 = findViewById(R.id.optionThree);
        confirmSubmt = findViewById(R.id.submitBtn);

        textColorDefaultRb = radio1.getTextColors();//save default text color of radio button
        TextColorDefaultCd = textViewCountdown.getTextColors(); //save default text color of clock

        Intent intent = getIntent();
        int categoryId = intent.getIntExtra(MainActivity.EXTRA_CATEGORYID, 0);//for getIntExtra default value needs to be passed.
        String categoryName = intent.getStringExtra(MainActivity.EXTRA_CATEGORY_NAME);
        String difficulty = intent.getStringExtra(MainActivity.EXTRA_DIFFICULTY);

        textViewCategory.setText("Category : " + categoryName );//both of these set the text value of txtView
        textViewDifficulty.setText("Difficulty: " + difficulty);

        if(savedInstanceState == null) {
            QuizDBHelper dbhelper = QuizDBHelper.getInstance(this);
            questionList = dbhelper.getQuestions(categoryId,difficulty);
            questionCountTotal = questionList.size();//gets question total

            Collections.shuffle(questionList);//shuffles questions

            showNextQuestion();
        } else{
            questionList = savedInstanceState.getParcelableArrayList(KEY_QUESTION_LIST);
            questionCountTotal = questionList.size();
            questionCounter = savedInstanceState.getInt(KEY_QUESTION_COUNT);
            currentQuestion = questionList.get(questionCounter - 1);//counter is 1 ahead so - 1 is added
            score = savedInstanceState.getInt(KEY_SCORE);
            timeLeftInMillis = savedInstanceState.getLong(KEY_MILLIS_LEFT);
            answered = savedInstanceState.getBoolean(KEY_ANSWERED);

            if(!answered){//not answered
                startCountDown();//resume time on rotation
            }else{
                updateCountDownText();
                showSolution();
            }
        }

        confirmSubmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!answered){ //in not answered
                    if(radio1.isChecked() || radio2.isChecked() || radio3.isChecked()){
                        checkAnswer();
                    }//end if
                    else{
                        Toast.makeText(QuizActivity.this, "Please make a selection", Toast.LENGTH_SHORT).show();
                    }//end else

                }else{
                    showNextQuestion();
                }
            }
        });
    }//end on create
    private void showNextQuestion(){
        radio1.setTextColor(textColorDefaultRb);
        radio2.setTextColor(textColorDefaultRb);
        radio3.setTextColor(textColorDefaultRb);

        rbGroup.clearCheck();//clears selections

        if(questionCounter < questionCountTotal){
            currentQuestion = questionList.get(questionCounter); //start as 0 increment with each question

            textViewQuesion.setText(currentQuestion.getQuestion()); //sets the questions to the text view
            radio1.setText(currentQuestion.getOption1());
            radio2.setText(currentQuestion.getOption2());
            radio3.setText(currentQuestion.getOption3());

            questionCounter++;//increase the question counter starts at one because of below line
            textViewQuestionCount.setText("Question: " + questionCounter +"/" + questionCountTotal);
            answered = false; //click confirm locks the question
            confirmSubmt.setText("Confirm");//not locked set to confrimed

            timeLeftInMillis = TIMER_IN_MILLIS;
            startCountDown();
        }//end if
        else{
            finishQuiz();
        }

    }//end method

    private void startCountDown(){
        countDownTimer = new CountDownTimer(timeLeftInMillis,1000) {//called every second
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished; //access outside countdown timer

                updateCountDownText();

            }

            @Override
            public void onFinish() {
                timeLeftInMillis = 0;//makes sure to display 0 when the timer is finished
                updateCountDownText();
                checkAnswer();//still lock answer

            }
        }.start();
    }//end start countdown

    private void updateCountDownText(){
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;//only get whats left after dividing by 60

        String timeFormated = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);

        textViewCountdown.setText(timeFormated);
        if(timeLeftInMillis < 10000){//less than 10 seconds
            textViewCountdown.setTextColor(Color.RED);
        }//end if
        else{
            textViewCountdown.setTextColor(TextColorDefaultCd);
        }//end else
    }//end method

    private void checkAnswer(){
        answered = true;
        countDownTimer.cancel();

        RadioButton rbSelcted = findViewById(rbGroup.getCheckedRadioButtonId()); //returns id of checked button and saves to rbselected

        int answerNumber = rbGroup.indexOfChild(rbSelcted) + 1;//retuen index of button in radio group sets to 1 and compares to answer

        if(answerNumber == currentQuestion.getAnswerNr()){
            score++; //if correct increase the score
            textViewScore.setText("Score: " + score);//display the score
        }
        showSolution();
    }//end method

    private void showSolution(){
        radio1.setTextColor(Color.RED);
        radio2.setTextColor(Color.RED);
        radio3.setTextColor(Color.RED); //sets text color to read upon confirm click

        switch (currentQuestion.getAnswerNr()){
            case 1:
                radio1.setTextColor(Color.GREEN);
                textViewQuesion.setText("A is Correct");
                break;
            case 2:
                radio2.setTextColor(Color.GREEN);
                textViewQuesion.setText("B is Correct");
                break;
            case 3:
                radio3.setTextColor(Color.GREEN);
                textViewQuesion.setText("C is Correct");
                break;
        }//end switch

        if(questionCounter < questionCountTotal){ //if there are any questions left
            confirmSubmt.setText("Next");
        }//end if
        else{//no questions left
            confirmSubmt.setText("finish");
        }//end else
    }
    private void finishQuiz(){
        Intent resultIntent = new Intent();//new intent to save score
        resultIntent.putExtra(EXTRA_SCORE, score);
        setResult(RESULT_OK, resultIntent);
        finish(); //closes the quiz as there are no more questions to answer
    }

    @Override
    public void onBackPressed() {
        if(backBtnPressedTime + 2000 > System.currentTimeMillis()){
            finishQuiz();
        }else{//more than 2 seconds passed since press
            Toast.makeText(this, "press back again to finish quiz", Toast.LENGTH_SHORT).show();
        }
        backBtnPressedTime = System.currentTimeMillis();//saves the above back button press to this spot then compares when pressed again
    }

    @Override
    protected void onDestroy() {
        super.onDestroy(); //cancels countdown timer

        if(countDownTimer != null){
            countDownTimer.cancel();
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_SCORE, score);
        outState.putInt(KEY_QUESTION_COUNT, questionCounter);
        outState.putLong(KEY_MILLIS_LEFT, timeLeftInMillis);
        outState.putBoolean(KEY_ANSWERED, answered);
        outState.putParcelableArrayList(KEY_QUESTION_LIST, questionList);
    }
}//end class

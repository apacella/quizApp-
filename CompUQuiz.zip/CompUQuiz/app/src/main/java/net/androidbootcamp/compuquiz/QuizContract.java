package net.androidbootcamp.compuquiz;

import android.provider.BaseColumns; //provides two more constants only uses ID to store ID with autoincrement

public final class QuizContract { //used as a constant to change the SQLite DB

    private QuizContract(){

    }//empty constructor prevents accidental creation of object of this class
    public static class CategoriesTable implements BaseColumns{
        //basecolumns automatically implements _id column of the table
        public static final String TABLE_NAME= "quiz_categories";
        public static final String COULMN_NAME = "name";
    }
    //keeps class is only used as a container for te below constants
    //create inner class for each table in the DB
    public static class QuestionsTable implements BaseColumns {
        public static final String TABLE_NAME = "Quiz_questions";
        public static final String COLUMN_QUESTION = "question";
        public static final String COLUMN_OPTION1 = "option1";
        public static final String COLUMN_OPTION2 = "option2";
        public static final String COLUMN_OPTION3 = "option3";
        public static final String COLUMN_ANSWER_NR = "answer_nr";
        public static final String COLUMN_DIFFICULTY = "difficulty";
        public static final String COLUMN_CATEGORY_ID = "category_id";

    }
}

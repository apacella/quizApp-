package net.androidbootcamp.compuquiz;

import androidx.annotation.NonNull;

public class Category {
    public static final int PROGRAMMING = 1;
    public static final int HARDWARE = 2;
   // public static final int GENERAL = 3;

    private int id;
    private String name;

    public Category(){

    }//end method empty constructor for adding more categories passes name to this

    public Category(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() { //defines what we want to return by overriding toString()
        return getName();
    }
}//end class

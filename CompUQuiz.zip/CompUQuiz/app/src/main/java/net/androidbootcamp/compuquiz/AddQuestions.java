package net.androidbootcamp.compuquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class AddQuestions extends AppCompatActivity {

    private TextView hintQuestion;
    private Spinner spinnerCategory;
    private Spinner spinnerDifficulty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_questions);

        hintQuestion = findViewById(R.id.hintAddQuestion);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty);
        loadCategories();
        loadDifficultyLevels();

        Button submitQuestionBtn = findViewById(R.id.submitQuestionBtn); //variable for later use
        submitQuestionBtn.setOnClickListener(new View.OnClickListener() { //user selects start, will eventually go to
            //categorty screen
            @Override
            public void onClick(View v) {
                Toast.makeText(AddQuestions.this,"Button Works!",Toast.LENGTH_SHORT).show();


            }
        });
        //QuizDBHelper.getInstance(this).addQuestion(hintQu estion);
    }

    private void loadCategories(){
        QuizDBHelper dbHelper = QuizDBHelper.getInstance(this);
        List<Category> categories = dbHelper.getALLCategories();

        ArrayAdapter<Category> adapterCategories = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapterCategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapterCategories);
    }
    private void loadDifficultyLevels(){
        String[] difficultyLevels = Question.getAllDifficultyLevels(); //calls method on the class itself

        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, difficultyLevels);
        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinnerDifficulty.setAdapter(adapterDifficulty);//fills spinner with the difficulty levels from getAllDifficultyLevels method
    }
}
